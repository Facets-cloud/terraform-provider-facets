### Postgres
module "postgres" {
  for_each = var.instances
  source   = "./postgres_flex"

  providers = {
    azurerm  = azurerm
    azurerm3 = azurerm3
    azurerm4 = azurerm4
    random   = random
  }
  server_name = "${each.key}-flexi-${var.environment}"

  database_names = ["${replace(each.key, "-", "")}${var.environment}"]
  location       = var.location

  sku_name   = each.value.sku_name == "" ? null : each.value.sku_name
  storage_mb = each.value.storage_mb == "" ? null : each.value.storage_mb
  backup_retention_days = each.value.backup_retention_days == "" ? null : each.value.backup_retention_days
  geo_redundant_backup_enabled = each.value.geo_redundant_backup_enabled == "" ? null : each.value.geo_redundant_backup_enabled
  ha_mode = each.value.ha_mode == "" ? null : each.value.ha_mode
  ha_standby_availability_zone = each.value.ha_standby_availability_zone == "" ? null : each.value.ha_standby_availability_zone
  private_dns_zone_resource_group = var.private_dns_zone_resource_group
  subnet_id = var.subnet_id
  maintenance_day = each.value.maintenance_day == null ? var.maintenance_day : each.value.maintenance_day
  maintenance_hour = each.value.maintenance_hour == null ? var.maintenance_hour : each.value.maintenance_hour
  maintenance_minute = each.value.maintenance_minute == null ? var.maintenance_minute : each.value.maintenance_minute
  random_password = var.random_password

  postgres_version                  = each.value.postgres_version
  create_mode                       = try(each.value.create_mode, null)
  creation_source_server_id         = try(each.value.source_server_id, null)
  point_in_time_restore_time_in_utc = try(each.value.point_in_time_restore_time_in_utc, null)
  resource_group_name               = var.resource_group_name
  tags = merge(var.tags,
    try(var.tag_library[each.key], {}),
    try(var.instances[each.key].tags, {})
  )
}

locals {
  # Aggregate replica data into a list of tuples
  psql_read_replica_tuples = flatten([for key, values in var.instances :
    [for name, replica_config in values.read_replicas :
      {
        "name"                 = "${key}-${var.environment}-flexi-rr-${replica_config.name}",
        "logical_name"         = "${key}-flexi-rr-${replica_config.name}",
        "config"               = replica_config,
        "source_database"      = module.postgres[key].instance_data,
        "source_database_name" = "${key}"
      }
    ]
    if try(values.read_replicas,null) != null
  ])
  # Construct a map where:
  #    The keys are names of read replicas to be created
  #    The value is an object containing the instance_data for the source databases
  psql_read_replicas = { for tuple in local.psql_read_replica_tuples : tuple.logical_name => tuple }

  psql_instances = merge(module.postgres, module.postgres_read_replicas)
}

# Read Replicas
module "postgres_read_replicas" {
  for_each            = local.psql_read_replicas
  source              = "./postgres_flex"

  providers = {
    azurerm  = azurerm
    azurerm3 = azurerm3
    azurerm4 = azurerm4
    random   = random
  }
  server_name         = each.value.name
  location            = var.location
  resource_group_name = var.resource_group_name
  private_dns_zone_resource_group = var.private_dns_zone_resource_group
  subnet_id = var.subnet_id
  ha_mode = null
  ha_standby_availability_zone = null

  backup_retention_days     = null
  create_mode               = "Replica"
  creation_source_server_id = each.value.source_database.id
  postgres_version          = each.value.source_database.version
  sku_name                  = each.value.source_database.sku_name
  storage_mb                = try(var.instances[each.value.source_database_name].storage_mb, each.value.source_database.storage_mb)

  maintenance_day = var.maintenance_day
  maintenance_hour = var.maintenance_hour
  maintenance_minute = var.maintenance_minute

  tags = merge(var.tags,
    try(var.tag_library[each.value.source_database_name], {}),
    try(var.instances[each.value.source_database_name].tags, {})
  )
}


locals {
  keyvault_secrets = { for k, v in module.postgres : "${lower(trimprefix(k, "psql-"))}-flexi-psql-password" => v.password }
}

module "keyvault_secrets" {
  source      = "./keyvault_secrets"
  count       = 1
  keyvault_id = var.keyvault_id
  secrets     = local.keyvault_secrets
}
