variable "secrets" {
  type      = map(string)
  sensitive = true
  description = "Name value pairs that are stored in the key vault as secrets."
}
variable "tags" {
  type    = map(string)
  default = {}
}
variable "keyvault_id" {
  description = "The id of the key vault in which to storage secrets."
}
