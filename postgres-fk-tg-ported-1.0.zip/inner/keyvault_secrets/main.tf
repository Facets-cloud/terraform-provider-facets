# since the input variable is sensitive, we need to extract to the keys
#  and mark them as nonsenstive
locals {
  keyvault_secret_names = nonsensitive(keys(var.secrets))
}

resource "azurerm_key_vault_secret" "main" {
  for_each     = { for k in local.keyvault_secret_names : k => var.secrets[k] }
  name         = each.key
  value        = each.value
  key_vault_id = var.keyvault_id
  tags         = var.tags
}
