locals {
  tags = var.tags
}


resource "random_password" "postgres" {
  count = (var.create_mode == null || var.create_mode == "Default") ? 1 : 0

  length           = var.random_password.length
  special          = var.random_password.special
  override_special = var.random_password.override_special
  min_lower        = var.random_password.min_lower
  min_numeric      = var.random_password.min_numeric
  min_special      = var.random_password.min_special
  min_upper        = var.random_password.min_upper
}

data "azurerm_private_dns_zone" "zone" {
  provider            = azurerm3
  name                = var.private_dns_zone_name
  resource_group_name = var.private_dns_zone_resource_group
}

resource "azurerm_postgresql_flexible_server" "server" {
  provider                  = azurerm4
  name                      = var.server_name
  location                  = var.location
  create_mode                       = var.create_mode
  source_server_id                  = var.creation_source_server_id
  point_in_time_restore_time_in_utc = var.point_in_time_restore_time_in_utc
  resource_group_name               = var.resource_group_name
  delegated_subnet_id               = var.subnet_id
  public_network_access_enabled     = false
  # Credentials only set for fresh (Default) instances; restore/replica modes inherit from source
  administrator_login    = (var.create_mode == null || var.create_mode == "Default") ? var.administrator_login : null
  administrator_password = try(random_password.postgres[0].result, null)

  backup_retention_days             = var.backup_retention_days
  geo_redundant_backup_enabled      = var.geo_redundant_backup_enabled
  private_dns_zone_id               = data.azurerm_private_dns_zone.zone.id
  sku_name                          = var.sku_name
  storage_mb                        = var.storage_mb
  tags                              = local.tags
  version                           = var.postgres_version

  dynamic "high_availability" {
    for_each = var.ha_mode != null ? [1] : []
    content {
      mode = var.ha_mode
      standby_availability_zone = var.ha_standby_availability_zone
    }
  }
  maintenance_window {
    day_of_week  = var.maintenance_day
    start_hour   = var.maintenance_hour
    start_minute = var.maintenance_minute
  }
  lifecycle {
    ignore_changes = [zone, high_availability.0.standby_availability_zone]
  }


}

resource "azurerm_postgresql_flexible_server_database" "db" {
  provider            = azurerm4
  count               = length(var.database_names)
  name                = var.database_names[count.index]
  server_id           = azurerm_postgresql_flexible_server.server.id
  charset             = "utf8"
  collation           = "en_US.utf8"
}
