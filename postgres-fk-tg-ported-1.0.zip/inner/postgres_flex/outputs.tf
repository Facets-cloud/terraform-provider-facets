output "username" {
  sensitive = true
  value     = var.administrator_login
}
output "instance_data" {
  value = azurerm_postgresql_flexible_server.server
}
output "name" {
  value = azurerm_postgresql_flexible_server.server.name
}
output "id" {
  value = azurerm_postgresql_flexible_server.server.id
}
output "tags" {
  value = azurerm_postgresql_flexible_server.server.tags
}
output "password" {
  sensitive = true
  value     = try(random_password.postgres[0].result, "")
}
