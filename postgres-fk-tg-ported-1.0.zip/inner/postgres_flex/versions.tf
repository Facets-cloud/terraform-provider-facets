terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.0"
    }
    azurerm3 = {
      source = "hashicorp/azurerm3"
    }
    azurerm4 = {
      source = "hashicorp/azurerm4"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.0"
    }
  }
}
