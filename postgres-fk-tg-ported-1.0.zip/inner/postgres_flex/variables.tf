variable "tags" {
  type    = map(any)
  default = {}
}

variable "create_mode" {
  default = null
}
variable "subnet_id" {}
variable "creation_source_server_id" {
  default = null
}
# Relevant doc https://docs.microsoft.com/en-us/azure/private-link/private-endpoint-dns
variable "private_dns_zone_name" {
  default = "privatelink.postgres.database.azure.com"
}
variable "private_dns_zone_resource_group" {}

variable "resource_group_name" {
  type        = string
  description = "The name of the resource group"
}
variable "server_name" {
  type        = string
  description = "The name of postgreSQL"
}

variable "location" {
  type        = string
  description = "The location where the postgreSQL is located."
}

variable "sku_name" {
  type        = string
  description = "The SKU Name for this PostgreSQL Server. The name of the SKU, follows the tier + family + cores pattern (e.g. B_Gen4_1, GP_Gen5_8)"
}

variable "storage_mb" {
  type        = string
  default     = 5120
  description = "Max storage allowed for a server."
}

variable "backup_retention_days" {
  type    = string
  default = 7
}

variable "administrator_login" {
  type        = string
  description = "The administrator login name for the PostgreSQL Server"
  default     = "fkadmin"

}

variable "postgres_version" {
  type        = string
  description = "The version of PostgreSQL server"
}

variable "database_names" {
  default = []
  type    = list(string)
}
variable "random_password" {
  description = "An object that configures a random password for the postgres instance. Defaults for the modules are set and can be safely used. This variable was added to allow existing environments to opt out updating their password. This should not typically need to be set."
  default = {
    length           = 24
    special          = true
    override_special = "_%@"
    min_lower        = 1
    min_numeric      = 1
    min_special      = 1
    min_upper        = 1
  }
  type = object({
    length           = number
    special          = bool
    override_special = string
    min_lower        = number
    min_numeric      = number
    min_special      = number
    min_upper        = number
  })
}

variable "maintenance_day" {
}
variable "maintenance_hour" {
}
variable "maintenance_minute" {
}
variable "geo_redundant_backup_enabled" {
  default = false
}
variable "ha_mode" {}
variable "ha_standby_availability_zone" {}

variable "point_in_time_restore_time_in_utc" {
  default     = null
  description = "The point in time to restore from (ISO 8601 format, e.g. 2024-01-01T12:00:00Z). Required when create_mode is PointInTimeRestore."
}
