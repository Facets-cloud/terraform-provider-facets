variable "random_password" {
  description = "An object that configures a random password for the postgres instances. Defaults for the modules are set and can be safely used. This variable was added to allow existing environments to opt out updating their password. This should not typically need to be set."
  default = {
    length           = 24
    special          = true
    override_special = "_%@"
    min_lower        = 1
    min_numeric      = 1
    min_special      = 1
    min_upper        = 1
  }
  type = object({
    length           = number
    special          = bool
    override_special = string
    min_lower        = number
    min_numeric      = number
    min_special      = number
    min_upper        = number
  })
}

variable "tag_library" {
  type    = map(map(string))
  default = {}
}
variable "instances" {
  type = map(object({
    tags                              = optional(map(string))
    sku_name                          = optional(string)
    storage_mb                        = optional(string)
    backup_retention_days             = optional(string)
    infrastructure_encryption_enabled = optional(bool)
    auto_grow_enabled                 = optional(bool)
    administrator_login               = optional(string)
    postgres_version                  = string
    public_network_access_enabled     = optional(bool)
    ssl_enforcement_enabled           = optional(bool)
    ssl_minimal_tls_version_enforced  = optional(string)
    ha_mode                           = optional(string)
    ha_standby_availability_zone      = optional(string)
    database_names                    = optional(list(string))
    maintenance_day                   = optional(number)
    maintenance_hour                  = optional(number)
    maintenance_minute                = optional(number)
    geo_redundant_backup_enabled      = optional(bool)
    read_replicas = optional(list(
      object({
        name = string
      })
    ))
    create_mode                       = optional(string)
    source_server_id                  = optional(string)
    point_in_time_restore_time_in_utc = optional(string)
    }
    )
  )
}
variable "private_dns_zone_resource_group" {
  description = "The resoource group of the private dns zone for the flexible server urls to be created."
}
variable "environment" {
  type = string
  description = "The suffix for database names."
}
variable "location" {
  type = string
  description = "The location where the postgreSQL is located."
}
variable "subnet_id" {}
variable "resource_group_name" {
  type = string
  description = "The name of the resource group."
}
variable "tags" {
  type = map(string)
  description = "Azure resource tags."
}
variable "keyvault_id" {
  default = null
  type    = string
  description = "The id of the key vault where the postgres password stored."
}
variable "maintenance_day" {
  default = 0
}
variable "maintenance_hour" {
  default = 7
}
variable "maintenance_minute" {
  default = 0
}
variable "geo_redundant_backup_enabled" {
  default = false
}
