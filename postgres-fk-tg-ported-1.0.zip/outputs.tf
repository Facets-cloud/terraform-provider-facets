locals {
  server_name = "${var.instance_name}-flexi-${local.env_label}"
  output_attributes = {
    server_name = local.server_name
    fqdn        = "${local.server_name}.postgres.database.azure.com"
    dns_name    = var.inputs.private_dns_zone != null ? "${local.dns_record_name}.${var.inputs.private_dns_zone.attributes.zone_name}" : local.dns_record_name
  }
  output_interfaces = {}
}
