locals {
  subnet_key                        = lookup(var.instance.spec, "subnet_key", "postgres")
  location                          = lookup(var.instance.spec, "location", "")
  private_dns_zone_rg               = lookup(var.instance.spec, "private_dns_zone_resource_group", "")
  tags                              = lookup(var.instance.spec, "tags", {})
  maintenance_day                   = lookup(var.instance.spec, "maintenance_day", 0)
  maintenance_hour                  = lookup(var.instance.spec, "maintenance_hour", 7)
  maintenance_minute                = lookup(var.instance.spec, "maintenance_minute", 0)
  geo_redundant_backup              = lookup(var.instance.spec, "geo_redundant_backup_enabled", false)
  backup_retention_days             = lookup(var.instance.spec, "backup_retention_days", "35")
  ha_mode                           = lookup(var.instance.spec, "ha_mode", "") == "Disabled" ? "" : lookup(var.instance.spec, "ha_mode", "")
  ha_standby_az                     = lookup(var.instance.spec, "ha_standby_availability_zone", "")
  read_replicas                     = lookup(var.instance.spec, "read_replicas", {})
  create_mode                       = lookup(var.instance.spec, "create_mode", null)
  source_server_id                  = lookup(var.instance.spec, "source_server_id", null)
  point_in_time_restore_time_in_utc = lookup(var.instance.spec, "point_in_time_restore_time_in_utc", null)
  server_fqdn     = "${local.server_name}.postgres.database.azure.com"
  env_label       = lookup(var.instance.spec, "env_suffix", "") != "" ? var.instance.spec.env_suffix : var.environment.name
  dns_record_name = lookup(var.instance.spec, "dns_record_name", null) != null ? var.instance.spec.dns_record_name : "psql-${var.instance_name}-flexi-${local.env_label}"
  random_password = merge({
    length           = 24
    special          = true
    override_special = "_%@"
    min_lower        = 1
    min_numeric      = 1
    min_special      = 1
    min_upper        = 1
  }, lookup(var.instance.spec, "random_password", {}))
}

module "inner" {
  source = "./inner"

  providers = {
    azurerm  = azurerm
    azurerm3 = azurerm3
    azurerm4 = azurerm4
    random   = random
  }

  resource_group_name             = var.inputs.resource_group.attributes.name
  subnet_id                       = var.inputs.network.attributes.subnets[local.subnet_key].id
  keyvault_id                     = var.inputs.keyvault != null ? var.inputs.keyvault.attributes.keyvault_id : null
  environment                     = local.env_label
  location                        = local.location
  private_dns_zone_resource_group = local.private_dns_zone_rg
  tags                            = merge(var.environment.cloud_tags, local.tags)
  tag_library                     = {}
  maintenance_day                 = local.maintenance_day
  maintenance_hour                = local.maintenance_hour
  maintenance_minute              = local.maintenance_minute
  geo_redundant_backup_enabled    = local.geo_redundant_backup
  random_password                 = local.random_password

  instances = {
    (var.instance_name) = {
      postgres_version                  = var.instance.spec.postgres_version
      sku_name                          = var.instance.spec.sku_name
      storage_mb                        = var.instance.spec.storage_mb
      backup_retention_days             = local.backup_retention_days
      ha_mode                           = local.ha_mode
      ha_standby_availability_zone      = local.ha_standby_az
      maintenance_day                   = local.maintenance_day
      maintenance_hour                  = local.maintenance_hour
      maintenance_minute                = local.maintenance_minute
      geo_redundant_backup_enabled      = local.geo_redundant_backup
      tags                              = local.tags
      read_replicas                     = length(local.read_replicas) > 0 ? [for k, v in local.read_replicas : { name = lookup(v, "name", k) }] : null
      create_mode                       = local.create_mode
      source_server_id                  = local.source_server_id
      point_in_time_restore_time_in_utc = local.point_in_time_restore_time_in_utc
    }
  }
}

resource "azurerm_private_dns_cname_record" "postgres" {
  count = var.inputs.private_dns_zone != null ? 1 : 0

  name                = local.dns_record_name
  zone_name           = var.inputs.private_dns_zone.attributes.zone_name
  resource_group_name = split("/", var.inputs.private_dns_zone.attributes.zone_id)[4]
  ttl                 = 300
  record              = local.server_fqdn
}
