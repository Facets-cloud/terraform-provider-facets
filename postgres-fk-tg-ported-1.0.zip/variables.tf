variable "instance" {
  type = object({
    kind    = string
    flavor  = string
    version = string
    spec = object({
      postgres_version                = string
      sku_name                        = optional(string)
      storage_mb                      = optional(string)
      backup_retention_days           = optional(string, "35")
      ha_mode                         = optional(string, "ZoneRedundant")
      ha_standby_availability_zone    = optional(string)
      geo_redundant_backup_enabled    = optional(bool, false)
      read_replicas                   = optional(any, {})
      tags                            = optional(map(string), {})
      location                        = optional(string)
      subnet_key                      = optional(string, "postgres")
      private_dns_zone_resource_group = optional(string)
      maintenance_day                 = optional(number, 0)
      maintenance_hour                = optional(number, 7)
      maintenance_minute              = optional(number, 0)
      random_password = optional(object({
        length           = number
        special          = bool
        override_special = string
        min_lower        = number
        min_numeric      = number
        min_special      = number
        min_upper        = number
      }))
      env_suffix                        = optional(string, "")
      dns_record_name                   = optional(string)
      create_mode                       = optional(string)
      source_server_id                  = optional(string)
      point_in_time_restore_time_in_utc = optional(string)
    })
  })
}

variable "instance_name" {
  type = string
}

variable "environment" {
  type = object({
    name        = string
    unique_name = string
    cloud_tags  = optional(map(string), {})
    variables   = optional(map(string), {})
  })
}

variable "inputs" {
  type = object({
    cloud_account = object({
      attributes = any
    })
    resource_group = object({
      attributes = object({
        name     = string
        location = string
      })
    })
    network = object({
      attributes = object({
        subnets = any
      })
    })
    keyvault = optional(object({
      attributes = object({
        keyvault_id = string
      })
    }))
    private_dns_zone = optional(object({
      attributes = object({
        zone_id   = string
        zone_name = string
      })
    }))
  })
}
